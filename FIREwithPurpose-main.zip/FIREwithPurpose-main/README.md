If you have somehow stumbled on this page, go to https://FIREwithPurpose.com to read more about my Financial Independence (FI) philosophy
