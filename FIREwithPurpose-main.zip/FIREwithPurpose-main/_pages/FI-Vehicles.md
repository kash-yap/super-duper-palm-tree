---
permalink: /FI-Vehicles
layout: page
title: FI Vehicles
---

### Financial Independence vehicles I am using

401k (traditional, after-tax)
<br>
HSA
<br>
IRA (traditional, Roth, SEP)
<br>
Brokerage account
<br>
529 account
<br>
ESPP
<br>
~~House~~


