---
permalink: /about
layout: page
title: About
 
---


I am just an IT guy on the path to FI
