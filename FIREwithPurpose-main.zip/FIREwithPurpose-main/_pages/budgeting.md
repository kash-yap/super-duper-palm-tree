---
permalink: /budgeting
layout: page
title: Simplest Budget
---


Do you keep elaborate sheet to track every penny that you spend? If you like doing that and it works for you, that's great!
