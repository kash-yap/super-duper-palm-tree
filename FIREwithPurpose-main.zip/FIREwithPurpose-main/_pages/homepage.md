---
permalink: /
layout: home

---

I know what you are thinking - does the world need another Financial Independence Retire Early (FIRE) blog? Stay with me for a little bit.

I have been following FI community for a while now and largely I agree with principles and outcome. So, why am I writing this when I can just retire and enjoy life the way god intended? because, it's important to not lose sight of purpose when you become financially independent.


Few years ago, when I had no kids, I would totally have retired, gone to an unknown island, and nobody would have ever heard from me again; end of my FIRE story!

Since you're hearing from me, I have (obviously) not vanished and I want to talk about something and people in FIRE community rarely talk about - making the world a better place for next generation! 

<br> 

I don't have all the answers yet; I don't even have all my thoughts together yet, so as they evolve, I'll post more but for now I want to leave you with the thought: what would you do when you achieve FIRE - **live your life as if it didn't exist or leave your mark by making the world a better place?!**

Here are some things that I want to do:

- Volunteer
- Maybe help create a personal financial course for schools?
- Mentor students so they can achieve more 
- ...

<br>

If you have any question, comment, or want to talk about [**FI Vehicles**](https://firewithpurpose.com/FI-Vehicles) that I am using, reach out to me at rk[at]FIREwithPurpose.com

 

 
